package com.pack.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class SecurityController {
	private static final Logger logger = LoggerFactory.getLogger(SecurityController.class);

	@RequestMapping(value = "/restricted", method = RequestMethod.GET)
	public String restrictedMethod(Model model) {
		logger.info("Returning restricted.jsp page");
		return "restricted";
	}

	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String UserAccess(Model model) {
		logger.info("Returning welcomeUser.jsp page");
		return "welcomeUser";
	}
}
